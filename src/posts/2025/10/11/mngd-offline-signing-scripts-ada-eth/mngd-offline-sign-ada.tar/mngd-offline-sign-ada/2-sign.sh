#!/usr/bin/env bash

# Signs claims/* and puts the signatures + pubkeys in claims-signed
#
# Usage: cd cardano-signer/src; nix-shell --fallback; cd ../..; ./2-sign.sh
#
# Claim messagess should be created manually using the midnight.gd portal with
# your custom addr and saved to claims/${wallet_name}-claim.txt
# WARNING: this script will edit the files to remove trailing newlines before signing.

# TODO Remove or edit if using another install method
export CS='node cardano-signer/src/cardano-signer.js'

mkdir -p claims-signed

for unsigned_claim in claims/*.txt; do

    wallet_name="$(basename "$unsigned_claim" | cut -d'-' -f1 | cut -d'.' -f1)"

    keys_basename="keys/${wallet_name}-stake"
    skey_path="${keys_basename}.skey"
    vkey_path="${keys_basename}.vkey"

    # this seems to be required after pasting the msg in some text editors
    perl -pi -e 'chomp if eof' "$unsigned_claim"

    read _ n_stars _ dest_addr tos_hash < "$unsigned_claim"

    out_sig_file="claims-signed/${wallet_name}-claim-signature.json"
    out_log_file="${out_sig_file}.log"

    # TODO if your origin and destination addresses are from different wallets,
    #      comment out the --address line here to avoid asserting that they match
    cmd="$CS sign --cip30 "
    cmd="$cmd --data-file '$unsigned_claim'"
    cmd="$cmd --secret-key '$skey_path'"
    cmd="$cmd --address '$dest_addr'"
    cmd="$cmd --json --out-file '$out_sig_file'"
    echo "$cmd" && eval "$cmd"

done
