#!/usr/bin/env bash

# Wipes sensitive info when you're done.
# Make sure to copy or move portal/*.txt somewhere first,
# and to shred any temporary seed phrase copies.
#
# Usage: cd cardano-signer/src; nix-shell --fallback; cd ../..; ./4-shred.sh

for d in seeds keys claims claims-signed portal; do
  [[ -d "$d" ]] || continue
  for f in ${d}/*; do
    echo "shred ${f}" && shred -n3 -u "$f"
  done
  rm -rf $d
done
