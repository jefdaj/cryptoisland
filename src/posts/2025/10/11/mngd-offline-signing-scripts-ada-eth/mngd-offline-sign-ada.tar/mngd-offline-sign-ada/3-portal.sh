#!/usr/bin/env bash

# Gathers all the info you need to paste in the portal.
#
# Usage: cd cardano-signer/src; nix-shell --fallback; cd ../..; ./3-portal.sh

mkdir -p portal

for sig_json in claims-signed/*-claim-signature.json; do

    wallet_name="$(basename "$sig_json" | cut -d'-' -f1 | cut -d'.' -f1)"

    portal_txt="portal/${wallet_name}-claim-info.txt"
    rm -f "$portal_txt"
    write_portal_txt() { echo -e "$1" >> "$portal_txt"; }

    write_portal_txt "midnight glacier drop claim info for ${wallet_name} wallet"
    write_portal_txt "\nnetwork:\ncardano"

    unsigned_claim="claims/${wallet_name}-claim.txt"
    read _ _ _ dest_addr _ < "$unsigned_claim"
    write_portal_txt "\ndestination addr:"
    write_portal_txt "$dest_addr"

    claim_txt="$(cat "claims/${wallet_name}-claim.txt")"
    write_portal_txt "\nclaim message:"
    write_portal_txt "$claim_txt"

    write_portal_txt "\nsignature:"
    write_portal_txt "$(cat "$sig_json" | jq '.COSE_Sign1_hex' | cut -d'"' -f2)"

    keypair_json="keys/${wallet_name}-stake.json"
    write_portal_txt "\npubkey:"
    write_portal_txt "$(cat "$keypair_json" | jq '.publicKey' | cut -d'"' -f2)"

done
