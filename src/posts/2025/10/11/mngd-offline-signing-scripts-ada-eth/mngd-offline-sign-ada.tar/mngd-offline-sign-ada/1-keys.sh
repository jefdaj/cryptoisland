#!/usr/bin/env bash

# Generate keys from seed phrases
# Usage: cd cardano-signer/src; nix-shell --fallback; cd ../..; ./1-keys.sh

# TODO Remove or edit if using another install method
export CS='node cardano-signer/src/cardano-signer.js'

# Edit the array to also generate other key types if you want
declare -A key_derivation_paths
key_derivation_paths["payment"]="payment"
key_derivation_paths["stake"]="stake"

mkdir -p keys

for seed_file in seeds/*.txt; do

    mnemonics="$(cat "$seed_file" | xargs echo)"
    mnemonics_arg="--mnemonics '$mnemonics'"

    for path_key in "${!key_derivation_paths[@]}"; do

        path_value="${key_derivation_paths[$path_key]}"
        [[ -z "$path_value" ]] && path_arg='' || path_arg="--path $path_value"

        wallet_name="$(basename "$seed_file" | cut -d'.' -f1 | cut -d'-' -f1)"
        keys_basename="keys/${wallet_name}-${path_key}"

        skey_path="${keys_basename}.skey"
        vkey_path="${keys_basename}.vkey"
        out_json="${keys_basename}.json"
        key_args="--out-skey ${skey_path} --out-vkey ${vkey_path}"

        cmd="$CS keygen --json"
        cmd="$cmd ${path_arg} ${key_args} ${mnemonics_arg}"

        echo "$cmd"
        eval "$cmd" > "$out_json"
    done

done
