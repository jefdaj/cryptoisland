#!/usr/bin/env bash

# Wipes sensitive info when you're done.
# Make sure to copy or move portal/*.txt somewhere first,
# and to shred any temporary seed phrase copies.
#
# Usage: cd nix-shell --fallback; ./2-shred.sh

for d in seeds-and-keys claims portal; do
  [[ -d "$d" ]] || continue
  for f in ${d}/*; do
    echo "shred ${f}" && shred -n3 -u "$f"
  done
  rm -rf $d
done
