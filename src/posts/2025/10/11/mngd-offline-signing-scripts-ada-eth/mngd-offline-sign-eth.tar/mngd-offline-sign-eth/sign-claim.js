#!/usr/bin/env node

// usage: ./sign-claim.js <walletname>

import { execSync } from 'child_process';
import { Wallet, hashMessage, Signature } from 'ethers';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';

// TODO exit with usage if no arg
const wallet_name = process.argv[2];

// any one of these can be used to construct the wallet
const wallet_paths = {
  seed: [`seeds-and-keys/${wallet_name}-seed.txt`],
  keystore: [`seeds-and-keys/${wallet_name}-keystore.json`, `seeds-and-keys/${wallet_name}-password.txt`],
  privkey: [`seeds-and-keys/${wallet_name}-privatekey.txt`]
};

var wallet = null;

if (existsSync(wallet_paths.seed[0])) {

  const seed_txt = readFileSync(wallet_paths.seed[0], 'utf8');
  const mnemonic = seed_txt.split(/\s+/).join(' ').trim();
  wallet = Wallet.fromPhrase(mnemonic);
  console.log(`created ${wallet_name} (${wallet.address}) from seed`)

} else if (existsSync(wallet_paths.keystore[0])) {

  const json_txt   = readFileSync(wallet_paths.keystore[0], 'utf8').trim();
  const passwd_txt = readFileSync(wallet_paths.keystore[1], 'utf8').trim();
  wallet = await Wallet.fromEncryptedJson(json_txt, passwd_txt);
  console.log(`created ${wallet_name} (${wallet.address}) from keystore + password`)

} else if (existsSync(wallet_paths.privkey[0])) {

  const pkey_txt = readFileSync(wallet_paths.privkey[0], 'utf8').trim();
  wallet = new Wallet(pkey_txt);
  console.log(`created ${wallet_name} (${wallet.address}) from private key`)

} else {

  console.log(`no seed or keys found for ${wallet_name}`);
  // TODO abort here

}

const claim_path  = `claims/${wallet_name}-claim.txt`;
console.log(`editing ${claim_path} to remove trailing newline, if any`);
try {
  const output = execSync(`perl -pi -e 'chomp if eof' "${claim_path}"`);
} catch (error) {
  console.log(`ERROR: ${error}`);
  // TODO abort here
}

console.log(`reading ${claim_path}`);
const message = readFileSync(claim_path, 'utf8');
  console.log(`message:\n${message}`);

  // console.log('\nsigning message');
  const sig_tmp = wallet.signingKey.sign(
  hashMessage(message)
);
const sig_str =
  sig_tmp.r.substring(2) +
  sig_tmp.s.substring(2) +
  (sig_tmp.yParity ? '1c' : '1b');
console.log(`produced signature:\n${sig_str}`);

const dest_addr = message.split(/\s+/)[3];
const portal_path = `portal/${wallet_name}-portal-info.txt`;
console.log(`writing all the info you need to ${portal_path}`);
const claim_info = `midnight glacier drop claim info for ${wallet_name} wallet

network:
ethereum

origin address:
${wallet.address}

destination address:
${dest_addr}

claim message:
${message}

signature:
${sig_str}
`;

try {
  mkdirSync('portal');
} catch (error) {}
writeFileSync(portal_path, claim_info);
