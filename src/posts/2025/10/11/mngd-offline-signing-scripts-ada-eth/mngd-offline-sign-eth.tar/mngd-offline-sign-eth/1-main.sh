#! /usr/bin/env bash

# Usage: ./main.sh

ls seeds-and-keys | cut -d'-' -f1 | sort | uniq | while read wallet_name; do
  ./sign-claim.js "$wallet_name"
done
