#! /usr/bin/env bash

# usage: ./addrs.sh <wallet-name>

# assumes you extracted the github release files to cwd
export PATH=$PWD/cardano-wallet-v2025-03-31-linux64:$PATH

set -e

export WALLET_NAME="$1"
[[ -z "$WALLET_NAME" ]] && echo "Usage: addrs.sh <wallet-name>" && exit 1

export SEED_FILE="seeds/${WALLET_NAME}-seed.txt"
export ADDRS_FILE="addrs/${WALLET_NAME}-addrs.txt"

mkdir -p addrs
write_addrs() { echo -e "$1" >> "$ADDRS_FILE"; }
dot() { echo -n "."; }

echo -n "$ADDRS_FILE "; dot

[[ -f "$ADDRS_FILE" ]] && rm "$ADDRS_FILE"
write_addrs "wallet name:\n${WALLET_NAME}"

# main root/account key
SEED_PRV="$(cat "$SEED_FILE" | xargs echo)"
ROOT_PRV="$(echo "$SEED_PRV" | cardano-address key from-recovery-phrase Shelley)"
ACCT_PRV="$(echo "$ROOT_PRV" | cardano-address key child "1852H/1815H/0H")"

# stake address
STAKE_PRV="$(echo "$ACCT_PRV" | cardano-address key child "2/0")"
STAKE_PUB="$(echo "$STAKE_PRV" | cardano-address key public --with-chain-code)"
STAKE_ADDR="$(echo "$STAKE_PUB" | cardano-address address stake --network-tag mainnet)"
write_addrs "\nstake address:"
write_addrs "$STAKE_ADDR"

# first 50 receive addresses
N_RECV_ADDRS=50
write_addrs "\nreceive addresses:"
for i in $(seq 0 $((N_RECV_ADDRS-1))); do

  pay_pub="$(echo "$ACCT_PRV" |
    cardano-address key child "0/${i}" |
    cardano-address key public --with-chain-code |
    cardano-address address payment --network-tag mainnet)"

  # combine payment and stake addrs to match wallets
  combined_addr="$(echo "$pay_pub" |
    cardano-address address delegation "$STAKE_PUB")"

  write_addrs "$combined_addr"

  # show progress
  (( i % 5 == 0 )) && dot

done
echo " ok"
