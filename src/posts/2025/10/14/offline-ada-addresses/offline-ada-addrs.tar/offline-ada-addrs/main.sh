#! /usr/bin/env bash

# Usage: ./main.sh

ls seeds | cut -d'-' -f1 | sort | uniq | while read wallet_name; do
  ./addrs.sh "$wallet_name"
done
